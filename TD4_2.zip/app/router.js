import EmberRouter from '@ember/routing/router';
import config from './config/environment';

const Router = EmberRouter.extend({
  location: config.locationType,
  rootURL: config.rootURL
});

Router.map(function() {
  this.route('developers', function() {
    this.route('new');
    this.route('edit',{path:'edit/:developer_id'});
    // penser a mettre :param car c'est les : qui definissent le param
    //param 1 = nom de la route et si on ne met pas de 2 ca revient a dire que
    //c'est le nom du param
  });
});

export default Router;
