import Route from '@ember/routing/route';
import EmberObject from '@ember/object';

export default Route.extend({
  model(){
    return {copy:{}};
  },
  actions:{
    save(dev){
      //let dev = model.copy;
      //this.store.createRecord(JSON.stringify(dev)); //encapsuler dans une ember object
      //this.store.createRecord(EmberObject.create(dev));
      dev = this.store.createRecord('developer',dev.copy);
      dev.save().then(this.transitionTo('developers'));
    }
  }
});
