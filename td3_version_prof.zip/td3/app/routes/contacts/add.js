import Route from '@ember/routing/route';

export default Route.extend({
  model(){
    return {copy:{}};
  },
  actions: {
    saveContact(contact,edited){
      contact=this.store.createRecord('contact',edited);
      contact.save().then(
        ()=>{this.transitionTo('contacts');}
      );
    }
  }
});
